const { React, i18n: { Messages } } = require('powercord/webpack');
const { Button } = require('powercord/components');
const { Modal } = require('powercord/components/modal');
const { close: closeModal } = require('powercord/modal');

module.exports = class PrivateModal extends React.PureComponent {
  constructor () {
    super();
  }

  render () {
    return <Modal className='powercord-text powercord-donate-modal'>
      <Modal.Content>
        <h3 className='powercord-donate-title'>Information</h3>
        <h4 className='powercord-donate-subtitle'>Discord</h4>
        <div className='powercord-donate-tier'>
          <img className='icon' src='https://cdn.discordapp.com/attachments/841244312545001493/865156799845498880/8482-blob-verification.png' alt='blobuwu'/>
          <div className='details'>
            This discord has an <b>Official</b> badge because it is official. So nobody can copy this discord, because only this discord has the badge. Here you can find the real employees from this discord.
          </div>
        </div>
      </Modal.Content>
      <Modal.Footer>
        <Button onClick={() => closeModal()}>Rozumím!</Button>
      </Modal.Footer>
    </Modal>;
  }
};
