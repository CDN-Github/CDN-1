const{gotoOrJoinServer:gotoOrJoinServer}=require("powercord/util"),{Clickable:Clickable,Tooltip:Tooltip,Icons:{badges:BadgeIcons}}=require("powercord/components"),{React:React,getModule:getModule}=require("powercord/webpack");

const Base = React.memo(({ color, tooltip, tooltipPosition, onClick, className, children }) => {
  const { profileBadge22 } = getModule([ 'profileBadge22' ], false);
  return (
    <Clickable onClick={onClick || (() => void 0)} className='powercord-badge-wrapper'>
      <Tooltip text={tooltip} position={tooltipPosition || 'top' } spacing={24}>
        <div className={`${profileBadge22} powercord-badge ${className}`} style={{ color: `#${color || '7289da'}` }}>
          {children}
        </div>
      </Tooltip>
    </Clickable>
  );
});

const Custom = React.memo(({ name, icon, tooltipPosition }) => (
  <Base
    tooltipPosition={tooltipPosition}
    onClick={() => {}}
    className='powercord-badge-cutie'
    tooltip={name}
  >
    <img src={icon} alt='Custom badge'/>
  </Base>
));

const GarlicStaff = React.memo(({ color }) => (
  <Base
    onClick={() => gotoOrJoinServer(`https://discord.gg/AjKJSBbGm2`)}
    className='powercord-badge-staff'
    tooltip='Garlic-Team Staff'
    color={color}
  >

    <BadgeIcons.Staff/>
  </Base>
));

const TheDevsStaff = React.memo(({ color }) => (
  <Base
    onClick={() => gotoOrJoinServer(`https://discord.gg/hVma4Yt`)}
    className='powercord-badge-cutie'
    tooltip='TheDevs Staff'
    color={color}
  >

    <img src='https://cdn.discordapp.com/attachments/841244312545001493/865138271377162240/gavel-solid.png' alt='TheDevsStaff'/>
  </Base>
));

module.exports={Custom:Custom,GarlicStaff:GarlicStaff,TheDevsStaff:TheDevsStaff};