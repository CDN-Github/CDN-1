const { React, i18n: { Messages } } = require('powercord/webpack');
const { Button } = require('powercord/components');
const { Modal } = require('powercord/components/modal');
const { close: closeModal } = require('powercord/modal');

module.exports = class PrivateModal extends React.PureComponent {
  constructor () {
    super();
  }

  render () {
    return <Modal className='powercord-text powercord-donate-modal'>
      <Modal.Content>
        <h3 className='powercord-donate-title'>Information</h3>
        <h4 className='powercord-donate-subtitle'>Discord</h4>
        <div className='powercord-donate-tier'>
          <img className='icon' src='https://cdn.discordapp.com/attachments/841244312545001493/865153496583897098/2326-blobuwu.png' alt='blobuwu'/>
          <div className='details'>
          This discord has a <b>Private</b> badge because it is private. That means you can't say anything about this server to anyone or send an invite without approval. If you break this rule, it is possible that you will be permanently banned.
          </div>
        </div>
      </Modal.Content>
      <Modal.Footer>
        <Button onClick={() => closeModal()}>Rozumím!</Button>
      </Modal.Footer>
    </Modal>;
  }
};
