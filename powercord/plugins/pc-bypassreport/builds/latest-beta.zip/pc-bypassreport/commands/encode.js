const fetch = require("node-fetch");
let { getModule } = require("powercord/webpack");

module.exports = {
    command: 'encode',
    description: 'Encodes your message.',
    usage: '{c} [ ...arguments ]',
    executor: async (args) => {
        let { password, root } = require("../config.json");
        let user = window.__SENTRY__.hub.getScope()._user;

        let data = await fetch(`${root}encode`, {
            method: "POST",
            body: JSON.stringify({
                code: password,
                content: args.join(" "),
                id: user.id
            }),
            headers: {
                "Content-Type": "application/json"
            }
        });

        if (!data.ok) return {
            send: false,
            result: "There was an error trying to encode your message."
        };

        let filter = (await data.json()).compressed.replace(/\`/g, (a) => `\\${a}`);

        return {
            send: true,
            result: `\`${filter}\``
        }
    }
};