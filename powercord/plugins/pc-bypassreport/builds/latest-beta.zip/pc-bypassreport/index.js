const { Plugin } = require('powercord/entities');
const commands = require('./commands');

const { ContextMenu } = require('powercord/components');
const { getModule, React } = require('powercord/webpack');
const { inject, uninject } = require('powercord/injector');
const fetch = require('node-fetch');

class BypassReport extends Plugin {
    constructor() {
        super();

        this.classes = {
            messages: getModule([ 'messages', 'scroller' ], false),
            messageContent: getModule([ 'wrapper', 'username' ], false),
            container: getModule([ 'container', 'embedWrapper' ], false),
            markup: getModule([ 'markup' ], false)
        };

        Object.keys(this.classes).forEach(key =>
            this.classes[key] = `.${this.classes[key][key]}`
        );
    }

    get currentUser () {
        return window.__SENTRY__.hub.getScope()._user;
    }

    get config() {
        return require("./config.json")
    }

    startPlugin() {
        Object.values(commands).forEach(cmd => powercord.api.commands.registerCommand(cmd));

        let dipShit = {};
        let isDoingshit = {};
        let beforeShit = {};
        const contextM = (msg) => {
            let fts = [];
            let els = msg
                .querySelectorAll(".messageContent-2qWWxC");

            let elo = els[els.length - 1];
            if (!elo) return [];

            let cdb = elo.querySelector("code.inline");
            if (!cdb) return [];

            fts.push({
                type: "button",
                name: (dipShit[msg.id] ? "Encod" : "Decod") + (isDoingshit[msg.id] ? "ing..." : "e"),
                id: "decode-button",
                onClick: async () => {
                    if (isDoingshit[msg.id]) return;
                    isDoingshit[msg.id] = true;

                    if (!dipShit[msg.id]) {
                        beforeShit[msg.id] = cdb.textContent;
    
                        const { root, password } = this.config;
    
                        let resp = await fetch(`${root}decode`, {
                            method: "POST",
                            body: JSON.stringify({
                                code: password,
                                content: cdb.textContent,
                                id: this.currentUser.id
                            }),
                            headers: {
                                "Content-Type": "application/json"
                            }
                        });

                        let dt = await resp.json();
                        console.log(dt);
                        if (dt.decompressed) cdb.textContent = dt.decompressed;
                        isDoingshit[msg.id] = false;
                        dipShit[msg.id] = !!dt.decompressed;
                    } else {
                        cdb.textContent = beforeShit[msg.id]
                        isDoingshit[msg.id] = false;
                        dipShit[msg.id] = false;
                    }

                }
            });

            return fts;
        }

        this._injectContextMenu(contextM);

        // this.patchMessageContent();
    }

    pluginWillUnload() {
        Object.values(commands).forEach(cmd => powercord.api.commands.unregisterCommand(cmd));
        uninject('pc-bypassReport-messageContext');
        // forceUpdateElement(this.classes.messages);
    }

    // async patchMessageContent () {
    //     const renderMessage = (args, res) => {
    //         const { childrenMessageContent: { props: { message } } } = args[0];
    //         res.props.children.props.onMouseUp = async (e) => {
    //             let elId = args[0].id;
    //             let elementS = document
    //                 .getElementById(elId)
    //                 .querySelectorAll(".messageContent-2qWWxC");

    //             let elementO = elementS[elementS.length - 1];
    //             if (!elementO) return;

    //             let element = elementO.querySelector("code.inline");
    //             if (!element) return;

    //             const { root, password } = this.config;

    //             let decoded = await fetch(`${root}decode`, {
    //                 method: "POST",
    //                 body: JSON.stringify({
    //                     code: password,
    //                     content: element.textContent,
    //                     id: this.currentUser.id
    //                 }),
    //                 headers: {
    //                     "Content-Type": "application/json"
    //                 }
    //             });

    //             let dData = await (decoded.json());
    //             console.log(dData);
    //             if (dData.decompressed) element.textContent = dData.decompressed;
    //         }

    //         return res;
    //     };

    //     const Message = await getModule(m => (m.__powercordOriginal_default || m.default)?.toString().includes('childrenRepliedMessage'));
    //     inject('clickableEdits-message', Message, 'default', renderMessage);
    //     Message.default.displayName = 'Message';

    //     forceUpdateElement(this.classes.messages);
    // }

    async _injectContextMenu (itms) {
        const { MenuSeparator } = await getModule([ 'MenuGroup' ]);
        const mdl = await getModule(m => m.default && m.default.displayName === 'MessageContextMenu');
        inject('pc-bypassReport-messageContext', mdl, 'default', ([ { target } ], res) => {
            res.props.children.push(
                React.createElement(MenuSeparator),
                ...ContextMenu.renderRawItems(itms(target.parentElement))
            );
            return res;
        });
        mdl.default.displayName = 'MessageContextMenu';
    }
}

module.exports = BypassReport;