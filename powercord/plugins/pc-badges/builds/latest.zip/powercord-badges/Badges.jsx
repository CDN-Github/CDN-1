const{gotoOrJoinServer:gotoOrJoinServer}=require("powercord/util"),{Clickable:Clickable,Tooltip:Tooltip,Icons:{badges:BadgeIcons}}=require("powercord/components"),{React:React,getModule:getModule}=require("powercord/webpack");
const { open: openModal } = require('powercord/modal');
const PrivateModal = require('./Modals/PrivateModal');
const OfficialModal = require('./Modals/OfficialModal');

const Base = React.memo(({ color, tooltip, tooltipPosition, onClick, className, children }) => {
  const { profileBadge22 } = getModule([ 'profileBadge22' ], false);
  return (
    <Clickable onClick={onClick || (() => void 0)} className='powercord-badge-wrapper'>
      <Tooltip text={tooltip} position={tooltipPosition || 'top' } spacing={24}>
        <div className={`${profileBadge22} powercord-badge ${className}`} style={{ color: `#${color || '7289da'}` }}>
          {children}
        </div>
      </Tooltip>
    </Clickable>
  );
});

const Custom = React.memo(({ name, icon, color, tooltipPosition }) => (
  <Base
    tooltipPosition={tooltipPosition}
    onClick={() => {
      if(name === "Private") openModal(PrivateModal)
      if(name.startsWith("Official")) openModal(OfficialModal)
    }}
    className='powercord-badge-cutie'
    color={color}
    tooltip={name}
  >
    <img src={icon} alt='Custom badge'/>
  </Base>
));

const GarlicStaff = React.memo(({ color }) => (
  <Base
    onClick={() => gotoOrJoinServer(`https://discord.gg/AjKJSBbGm2`)}
    className='powercord-badge-cutie'
    tooltip='Garlic-Team Staff'
    color={color}
  >

    <BadgeIcons.Staff/>
  </Base>
));

const TheDevsStaff = React.memo(({ color }) => (
  <Base
    onClick={() => gotoOrJoinServer(`https://discord.gg/hVma4Yt`)}
    className='powercord-badge-cutie'
    tooltip='TheDevs Staff'
    color={color}
  >

  <i class="fas fa-gavel"></i>
  </Base>
));

module.exports={Custom:Custom,GarlicStaff:GarlicStaff,TheDevsStaff:TheDevsStaff};