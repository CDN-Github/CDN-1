echo "Starting installer"
node installer.js