const { execSync } = require("child_process");
let InfoLogger = (data) => console.log(`\x1b[30m\x1b[104m[ INFO ]\x1b[0m ${data}`);
let SuccessLogger = (data) => console.log(`\x1b[30m\x1b[102m[ SUCCESS ]\x1b[0m ${data}`);
let WarnLogger = (data) => console.log(`\x1b[30m\x1b[103m[ WARN ]\x1b[0m ${data}`);
let DangerLogger = (data) => console.log(`\x1b[30m\x1b[101m[ DANGER ]\x1b[0m ${data}`);

(async () => {
    InfoLogger("Checking nodejs version...")
    let t = Number(await execSync("node --version").toString().slice(1).split(".")[0])
    if(t < 14) WarnLogger(`The recommended version is NodeJS >= 14.x`)
    else SuccessLogger(`You meet the nodejs requirements!`)

    InfoLogger("Downloading dependencies...")
    await execSync("npm i node-fetch prompts fs");

    const fs = require("fs");
    const prompts = require('prompts');
    let pluginPathFolder = "src/Powercord/plugins/", pluginPathFile = "src/Powercord/plugins/pc-badges"
    
    const { value } = await prompts({
        type: 'select',
        name: 'value',
        message: 'Do you want stable or beta?',
        choices: [
            { title: "Stable", value: "stable" },
            { title: "Beta", value: "beta" }
        ]
    });

    let url = `https://raw.githubusercontent.com/CDN-Github/CDN-1/main/powercord/plugins/pc-badges/builds/latest`
    if(value == "beta") url += "-beta"
    url += ".zip"

    InfoLogger("Downloading build...")
    console.log("\x1b[90m-------------------------------------------------------------------------------------------\x1b[0m")
    await execSync(`curl -o installedBuild.zip ${url}`)
    console.log("\x1b[90m-------------------------------------------------------------------------------------------\x1b[0m")

    InfoLogger("Searching for Powercord...")

    InfoLogger("Extracting build...")
    await execSync("powershell Expand-Archive -Force -Path installedBuild.Zip -DestinationPath installedBuild")
    await execSync(`powershell Copy-item -Force -Recurse -Verbose installedBuild/powercord-badges -Destination ${pluginPathFile}`)

    InfoLogger("Removing temp files...")
    await execSync("powershell Remove-Item -Force –Path installedBuild –recurse")
    await execSync("powershell rm -Force installedBuild.zip")

    SuccessLogger("Successfully installed!")
})();

process.on("warning", WarnLogger)
process.on("uncaughtException", (e) => {
    DangerLogger(e)
    return;
})