const fetch = require("node-fetch");
let { getModule } = require("powercord/webpack");

module.exports = {
    command: 'decode',
    description: 'Decodes your message. (use a codeblock)',
    usage: '{c} [ ...arguments ]',
    executor: async (args) => {
      let { password, root } = require("../config.json");
      let user = window.__SENTRY__.hub.getScope()._user;

      let data = await fetch(`${root}decode`, {
          method: "POST",
          body: JSON.stringify({
              code: password,
              content: args.join(" ").slice(1, -1),
              id: user.id
          }),
          headers: {
              "Content-Type": "application/json"
          }
      });

      if (!data.ok) return {
          send: false,
          result: "There was an error trying to decode your message."
      };

      return {
          send: false,
          result: {
            type: "rich",
            title: "Decoded Message",
            fields: [
              {
                name: "👾 Decoded 👾",
                value: `\`\`\`\n${(await data.json()).decompressed}\`\`\``
              }
            ]
          }
      }
    }
};